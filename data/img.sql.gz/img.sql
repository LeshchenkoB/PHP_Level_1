-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1:3307
-- Время создания: Окт 24 2019 г., 20:26
-- Версия сервера: 5.6.43
-- Версия PHP: 7.2.22

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `lesson_5`
--

-- --------------------------------------------------------

--
-- Структура таблицы `img`
--

CREATE TABLE `img` (
  `id` int(11) NOT NULL,
  `caption` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `src_big` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `src_small` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `count-view` int(11) NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `img`
--

INSERT INTO `img` (`id`, `caption`, `src_big`, `src_small`, `count-view`, `description`, `price`) VALUES
(1, 'Название товара', '/big/1.jpg', '/small/1.jpg', 4, 'Произвольное описание товара. Это описние хранится в БД и вытягивается автоматически. ID данного описания товара совпадает с последней цифрой в названии товара и равно = ', 1000),
(2, 'Название товара', '/big/2.jpg', '/small/2.jpg', 8, 'Произвольное описание товара. Это описние хранится в БД и вытягивается автоматически. ID данного описания товара совпадает с последней цифрой в названии товара и равно = ', 2000),
(4, 'Название товара', '/big/3.png', '/small/3.png', 0, 'Произвольное описание товара. Это описние хранится в БД и вытягивается автоматически. ID данного описания товара совпадает с последней цифрой в названии товара и равно = ', 4000),
(6, 'Название товара', '/big/4.jpg', '/small/4.jpg', 0, 'Произвольное описание товара. Это описние хранится в БД и вытягивается автоматически. ID данного описания товара совпадает с последней цифрой в названии товара и равно = ', 6000),
(8, 'Название товара', '/big/5.jpg', '/small/5.jpg', 0, 'Произвольное описание товара. Это описние хранится в БД и вытягивается автоматически. ID данного описания товара совпадает с последней цифрой в названии товара и равно = ', 8000),
(10, 'Название товара', '/big/6.jpg', '/small/6.jpg', 11, 'Произвольное описание товара. Это описние хранится в БД и вытягивается автоматически. ID данного описания товара совпадает с последней цифрой в названии товара и равно = ', 10000);

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `img`
--
ALTER TABLE `img`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `img`
--
ALTER TABLE `img`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
